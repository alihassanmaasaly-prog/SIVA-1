import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:siva/main.dart';

void main() {
  testWidgets('SIVA app loads', (WidgetTester tester) async {
    await tester.pumpWidget(const SivaApp());
    expect(find.text('SIVA'), findsOneWidget);
  });
}
