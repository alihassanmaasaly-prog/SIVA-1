# App Icon

Place your app icon image here with filename: icon.png

Requirements:
- Size: 1024x1024 pixels (square)
- Format: PNG
- Transparent background (optional)
- The icon will be automatically resized for all platforms

You can create an icon using:
1. Canva (canva.com) - Free
2. Ideogram (ideogram.ai) - AI generated
3. Leonardo.ai - AI generated
4. App Icon Generator (appicon.co) - Generate all sizes

After placing icon.png, run:
  flutter pub get
  flutter pub run flutter_launcher_icons
