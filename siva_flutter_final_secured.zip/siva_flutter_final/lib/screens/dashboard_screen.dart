import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:percent_indicator/percent_indicator.dart';
import '../services/auth_service.dart';
import '../services/revenuecat_service.dart';
import 'subjects_screen.dart';
import 'tasks_screen.dart';
import 'pomodoro_screen.dart';
import 'notes_screen.dart';
import 'chat_screen.dart';
import 'ai_chat_screen.dart';
import 'premium_screen.dart';
import 'profile_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _index = 0;
  final _screens = const [HomeTab(), SubjectsScreen(), TasksScreen(), PomodoroScreen(), NotesScreen()];

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthService>().user;
    final isPro = context.watch<RevenueCatService>().isPro;

    return Scaffold(
      appBar: AppBar(
        title: const Text('SIVA'),
        actions: [
          if (!isPro)
            IconButton(
              icon: const Icon(Icons.star, color: Colors.amber),
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PremiumScreen())),
            ),
          IconButton(
            icon: const Icon(Icons.chat_bubble_outline),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ChatScreen())),
          ),
          IconButton(
            icon: const Icon(Icons.person_outline),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileScreen())),
          ),
        ],
      ),
      body: _screens[_index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.book_outlined), selectedIcon: Icon(Icons.book), label: 'Subjects'),
          NavigationDestination(icon: Icon(Icons.assignment_outlined), selectedIcon: Icon(Icons.assignment), label: 'Tasks'),
          NavigationDestination(icon: Icon(Icons.timer_outlined), selectedIcon: Icon(Icons.timer), label: 'Timer'),
          NavigationDestination(icon: Icon(Icons.note_outlined), selectedIcon: Icon(Icons.note), label: 'Notes'),
        ],
      ),
    );
  }
}

class HomeTab extends StatelessWidget {
  const HomeTab({super.key});

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthService>().user;
    final isPro = context.watch<RevenueCatService>().isPro;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF1A237E), Color(0xFF3949AB)]),
              borderRadius: BorderRadius.circular(24),
              boxShadow: [BoxShadow(color: const Color(0xFF1A237E).withOpacity(0.3), blurRadius: 20, offset: const Offset(0, 8))],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    CircleAvatar(
                      radius: 28,
                      backgroundColor: Colors.white.withOpacity(0.2),
                      child: Text((user?.email?.substring(0,1).toUpperCase() ?? 'U'), style: const TextStyle(fontSize: 24, color: Colors.white, fontWeight: FontWeight.bold)),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Welcome, ' + (user?.email?.split('@')[0] ?? 'Student') + '!', style: GoogleFonts.cairo(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white)),
                          Text(isPro ? 'SIVA Pro' : 'Free Version', style: TextStyle(fontSize: 13, color: Colors.white.withOpacity(0.8))),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Text('Keep going, today is your day!', style: GoogleFonts.cairo(fontSize: 14, color: Colors.white70)),
              ],
            ),
          ).animate().fadeIn(duration: 600.ms).slideY(begin: 0.2),

          const SizedBox(height: 24),

          Row(
            children: [
              _buildStatCard('Subjects', '5', Icons.book, const Color(0xFF00897B), 0.6),
              const SizedBox(width: 12),
              _buildStatCard('Tasks', '12', Icons.assignment, const Color(0xFFFB8C00), 0.4),
              const SizedBox(width: 12),
              _buildStatCard('Hours', '24', Icons.timer, const Color(0xFF7B1FA2), 0.8),
            ],
          ).animate().fadeIn(duration: 800.ms, delay: 200.ms),

          const SizedBox(height: 24),

          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Weekly Progress', style: GoogleFonts.cairo(fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 16),
                LinearPercentIndicator(
                  lineHeight: 14,
                  percent: 0.65,
                  backgroundColor: Colors.grey.shade200,
                  progressColor: const Color(0xFF1A237E),
                  barRadius: const Radius.circular(10),
                  trailing: Text('65%', style: GoogleFonts.cairo(fontWeight: FontWeight.bold)),
                ),
                const SizedBox(height: 8),
                Text('Completed 13 of 20 study hours', style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
              ],
            ),
          ).animate().fadeIn(duration: 800.ms, delay: 400.ms),

          const SizedBox(height: 24),

          Text('Quick Access', style: GoogleFonts.cairo(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          _buildQuickAction(context, 'Add New Subject', Icons.add_circle, const Color(0xFF00897B), const SubjectsScreen()),
          const SizedBox(height: 10),
          _buildQuickAction(context, 'Add New Task', Icons.add_task, const Color(0xFFFB8C00), const TasksScreen()),
          const SizedBox(height: 10),
          _buildQuickAction(context, 'Start Study Session', Icons.timer, const Color(0xFF7B1FA2), const PomodoroScreen()),
          const SizedBox(height: 10),
          _buildQuickAction(context, 'SIVA AI Assistant', Icons.psychology, const Color(0xFF00BFA5), const AIChatScreen()),

          const SizedBox(height: 24),

          if (!isPro)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFFFFD54F), Color(0xFFFFB300)]),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                children: [
                  const Icon(Icons.star, color: Colors.white, size: 40),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('SIVA Pro', style: GoogleFonts.cairo(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
                        Text('Unlimited subjects + No ads + Smart analysis', style: TextStyle(fontSize: 12, color: Colors.white.withOpacity(0.9))),
                      ],
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PremiumScreen())),
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.white, foregroundColor: const Color(0xFFFFB300)),
                    child: const Text('Upgrade'),
                  ),
                ],
              ),
            ).animate().shake(duration: 500.ms, delay: 600.ms),
        ],
      ),
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color, double percent) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(16)),
        child: Column(
          children: [
            Icon(icon, color: color, size: 28),
            const SizedBox(height: 8),
            Text(value, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: color)),
            Text(title, style: TextStyle(fontSize: 12, color: color.withOpacity(0.8))),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickAction(BuildContext context, String title, IconData icon, Color color, Widget page) {
    return InkWell(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => page)),
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)]),
        child: Row(children: [Icon(icon, color: color), const SizedBox(width: 12), Text(title, style: const TextStyle(fontSize: 15)), const Spacer(), const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey)]),
      ),
    );
  }
}
