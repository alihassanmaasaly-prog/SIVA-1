import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../services/revenuecat_service.dart';

class PremiumScreen extends StatelessWidget {
  const PremiumScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final rc = context.watch<RevenueCatService>();
    final offerings = rc.offerings;

    return Scaffold(
      appBar: AppBar(title: const Text('SIVA Pro')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            Container(
              width: 120, height: 120,
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Color(0xFFFFD54F), Color(0xFFFFB300)]),
                shape: BoxShape.circle,
                boxShadow: [BoxShadow(color: Colors.amber.withOpacity(0.4), blurRadius: 30)],
              ),
              child: const Icon(Icons.star, color: Colors.white, size: 60),
            ).animate().scale(duration: 600.ms, curve: Curves.elasticOut),
            const SizedBox(height: 24),
            Text('Upgrade to SIVA Pro', style: GoogleFonts.cairo(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('Unlock your full study potential', style: TextStyle(fontSize: 14, color: Colors.grey.shade600)),
            const SizedBox(height: 32),

            _buildFeature(Icons.all_inclusive, 'Unlimited Subjects', 'Add any number of study subjects'),
            _buildFeature(Icons.block, 'No Ads', 'Clean experience without ads'),
            _buildFeature(Icons.analytics, 'Smart Analysis', 'Know your strengths and weaknesses'),
            _buildFeature(Icons.cloud_sync, 'Cloud Sync', 'Your data is safe in the cloud'),
            _buildFeature(Icons.palette, 'Exclusive Themes', 'Customize the app as you like'),

            const SizedBox(height: 32),

            if (offerings != null && offerings.current != null)
              ...offerings.current!.availablePackages.map((pkg) => _buildPlanCard(context, pkg))
            else
              Column(
                children: [
                  _buildPlanButton(context, 'Weekly', '\$0.99', 'One week trial', Colors.grey.shade700),
                  const SizedBox(height: 12),
                  _buildPlanButton(context, 'Monthly', '\$2.99', 'Most Popular', const Color(0xFF1A237E), isPopular: true),
                  const SizedBox(height: 12),
                  _buildPlanButton(context, 'Yearly', '\$19.99', 'Save 45% + 2 months free', const Color(0xFF00897B)),
                ],
              ),

            const SizedBox(height: 16),
            TextButton.icon(
              onPressed: () => rc.restorePurchases(),
              icon: const Icon(Icons.restore),
              label: const Text('Restore Purchases'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFeature(IconData icon, String title, String desc) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: const Color(0xFF1A237E).withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
            child: Icon(icon, color: const Color(0xFF1A237E)),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
                Text(desc, style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPlanCard(BuildContext context, dynamic pkg) {
    final rc = context.read<RevenueCatService>();
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        title: Text(pkg.storeProduct.title),
        subtitle: Text(pkg.storeProduct.description),
        trailing: ElevatedButton(
          onPressed: () async {
            final success = await rc.purchasePackage(pkg);
            if (success && context.mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Upgraded to Pro!'), backgroundColor: Colors.green),
              );
              Navigator.pop(context);
            }
          },
          child: Text(pkg.storeProduct.priceString),
        ),
      ),
    );
  }

  Widget _buildPlanButton(BuildContext context, String name, String price, String desc, Color color, {bool isPopular = false}) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: isPopular ? color : Colors.grey.shade300, width: isPopular ? 2 : 1),
        borderRadius: BorderRadius.circular(16),
        gradient: isPopular ? LinearGradient(colors: [color, color.withOpacity(0.8)]) : null,
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        title: Row(
          children: [
            Text(name, style: TextStyle(fontWeight: FontWeight.bold, color: isPopular ? Colors.white : Colors.black)),
            if (isPopular) ...[
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(color: Colors.amber, borderRadius: BorderRadius.circular(8)),
                child: const Text('Most Popular', style: TextStyle(fontSize: 10, color: Colors.white)),
              ),
            ],
          ],
        ),
        subtitle: Text(desc, style: TextStyle(color: isPopular ? Colors.white70 : Colors.grey)),
        trailing: Text(price, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: isPopular ? Colors.white : color)),
      ),
    );
  }
}
