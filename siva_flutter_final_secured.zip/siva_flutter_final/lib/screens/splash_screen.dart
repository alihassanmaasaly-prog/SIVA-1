import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import '../services/auth_service.dart';
import 'login_screen.dart';
import 'dashboard_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 3), () {
      if (!mounted) return;
      final auth = context.read<AuthService>();
      Navigator.pushReplacement(
        context, MaterialPageRoute(
          builder: (_) => auth.user == null ? const LoginScreen() : const DashboardScreen(),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [Color(0xFF1A237E), Color(0xFF3949AB), Color(0xFF00BFA5)],
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 140, height: 140,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.15),
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white.withOpacity(0.3), width: 2),
                  boxShadow: [BoxShadow(color: Colors.white.withOpacity(0.2), blurRadius: 40, spreadRadius: 10)],
                ),
                child: Center(
                  child: Text('S', style: GoogleFonts.poppins(
                    fontSize: 72, fontWeight: FontWeight.bold, color: Colors.white,
                  )).animate().scale(duration: 800.ms, curve: Curves.elasticOut),
                ),
              ).animate().scale(duration: 600.ms).then().shake(duration: 400.ms),
              const SizedBox(height: 32),
              Text('SIVA', style: GoogleFonts.poppins(
                fontSize: 42, fontWeight: FontWeight.bold, color: Colors.white, letterSpacing: 8,
              )).animate().fadeIn(duration: 800.ms, delay: 400.ms).slideY(begin: 0.3),
              const SizedBox(height: 12),
              Text('Smart Study Planner', style: GoogleFonts.cairo(
                fontSize: 18, color: Colors.white.withOpacity(0.9),
              )).animate().fadeIn(duration: 600.ms, delay: 800.ms),
              const SizedBox(height: 60),
              SizedBox(width: 40, height: 40,
                child: CircularProgressIndicator(
                  strokeWidth: 3,
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.white.withOpacity(0.8)),
                ),
              ).animate().fadeIn(duration: 400.ms, delay: 1200.ms),
            ],
          ),
        ),
      ),
    );
  }
}
