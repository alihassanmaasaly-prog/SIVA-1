import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:flutter_animate/flutter_animate.dart';

class SubjectsScreen extends StatefulWidget {
  const SubjectsScreen({super.key});
  @override State<SubjectsScreen> createState() => _SubjectsScreenState();
}

class _SubjectsScreenState extends State<SubjectsScreen> {
  final _nameCtrl = TextEditingController();
  final _colors = [Colors.teal, Colors.blue, Colors.orange, Colors.purple, Colors.red, Colors.green, Colors.pink, Colors.indigo];
  int _selectedColor = 0;

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return const Center(child: Text('Please login'));

    return Scaffold(
      appBar: AppBar(title: const Text('Study Subjects')),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('users').doc(user.uid).collection('subjects').orderBy('createdAt', descending: true).snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final docs = snapshot.data!.docs;
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: docs.length + 1,
            itemBuilder: (context, index) {
              if (index == 0) return _buildAddCard();
              final doc = docs[index - 1];
              final data = doc.data() as Map<String, dynamic>;
              return _buildSubjectCard(doc.id, data, user.uid).animate().fadeIn(duration: 400.ms, delay: (index * 100).ms);
            },
          );
        },
      ),
    );
  }

  Widget _buildAddCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Add New Subject', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 12),
            TextField(
              controller: _nameCtrl,
              decoration: InputDecoration(labelText: 'Subject Name', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12))),
            ),
            const SizedBox(height: 12),
            const Text('Choose Color:', style: TextStyle(fontSize: 12)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: List.generate(_colors.length, (i) => GestureDetector(
                onTap: () => setState(() => _selectedColor = i),
                child: Container(
                  width: 36, height: 36,
                  decoration: BoxDecoration(color: _colors[i], shape: BoxShape.circle, border: _selectedColor == i ? Border.all(color: Colors.black, width: 3) : null),
                ),
              )),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(onPressed: _addSubject, icon: const Icon(Icons.add), label: const Text('Add Subject')),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSubjectCard(String id, Map<String, dynamic> data, String uid) {
    final color = _colors[data['colorIndex'] ?? 0];
    return Slidable(
      endActionPane: ActionPane(motion: const ScrollMotion(), children: [
        SlidableAction(onPressed: (_) => _deleteSubject(id, uid), backgroundColor: Colors.red, foregroundColor: Colors.white, icon: Icons.delete, label: 'Delete'),
      ]),
      child: Card(
        margin: const EdgeInsets.only(bottom: 12),
        child: ListTile(
          leading: Container(width: 12, height: 40, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(6))),
          title: Text(data['name'] ?? 'Subject', style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text('${data['hoursPerWeek'] ?? 2} hours/week'),
          trailing: const Icon(Icons.arrow_back_ios, size: 16, color: Colors.grey),
        ),
      ),
    );
  }

  Future<void> _addSubject() async {
    if (_nameCtrl.text.trim().isEmpty) return;
    final user = FirebaseAuth.instance.currentUser!;
    await FirebaseFirestore.instance.collection('users').doc(user.uid).collection('subjects').add({
      'name': _nameCtrl.text.trim(), 'colorIndex': _selectedColor, 'hoursPerWeek': 2, 'createdAt': Timestamp.now(),
    });
    _nameCtrl.clear(); setState(() => _selectedColor = 0);
  }

  Future<void> _deleteSubject(String id, String uid) async {
    await FirebaseFirestore.instance.collection('users').doc(uid).collection('subjects').doc(id).delete();
  }

  @override void dispose() { _nameCtrl.dispose(); super.dispose(); }
}
