import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import 'package:flutter_slidable/flutter_slidable.dart';

class TasksScreen extends StatefulWidget {
  const TasksScreen({super.key});
  @override State<TasksScreen> createState() => _TasksScreenState();
}

class _TasksScreenState extends State<TasksScreen> {
  final _titleCtrl = TextEditingController();
  String? _selectedSubjectId;
  DateTime _dueDate = DateTime.now().add(const Duration(days: 1));
  int _priority = 1;

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return const Center(child: Text('Please login'));

    return Scaffold(
      appBar: AppBar(title: const Text('Tasks & Assignments')),
      body: Column(
        children: [
          _buildAddForm(user.uid),
          const Divider(),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance.collection('users').doc(user.uid).collection('tasks').orderBy('dueDate').snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
                final docs = snapshot.data!.docs;
                if (docs.isEmpty) return const Center(child: Text('No tasks yet'));
                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: docs.length,
                  itemBuilder: (context, index) {
                    final doc = docs[index];
                    final data = doc.data() as Map<String, dynamic>;
                    return _buildTaskCard(doc.id, data, user.uid);
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAddForm(String uid) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('users').doc(uid).collection('subjects').snapshots(),
      builder: (context, snapshot) {
        final subjects = snapshot.data?.docs ?? [];
        return Card(
          margin: const EdgeInsets.all(16),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Add New Task', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                TextField(controller: _titleCtrl, decoration: InputDecoration(labelText: 'Task Title', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)))),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: _selectedSubjectId,
                  decoration: InputDecoration(labelText: 'Subject', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12))),
                  items: subjects.map((s) { final d = s.data() as Map<String, dynamic>; return DropdownMenuItem(value: s.id, child: Text(d['name'] ?? 'Subject')); }).toList(),
                  onChanged: (v) => setState(() => _selectedSubjectId = v),
                ),
                const SizedBox(height: 12),
                ListTile(
                  title: Text('Due Date: ' + DateFormat('yyyy-MM-dd').format(_dueDate)),
                  trailing: const Icon(Icons.calendar_today),
                  onTap: () async {
                    final picked = await showDatePicker(context: context, initialDate: _dueDate, firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 365)));
                    if (picked != null) setState(() => _dueDate = picked);
                  },
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    const Text('Priority: '),
                    ChoiceChip(label: const Text('Normal'), selected: _priority == 1, onSelected: (_) => setState(() => _priority = 1)),
                    const SizedBox(width: 8),
                    ChoiceChip(label: const Text('Important', style: TextStyle(color: Colors.white)), selected: _priority == 2, selectedColor: Colors.orange, onSelected: (_) => setState(() => _priority = 2)),
                    const SizedBox(width: 8),
                    ChoiceChip(label: const Text('Urgent', style: TextStyle(color: Colors.white)), selected: _priority == 3, selectedColor: Colors.red, onSelected: (_) => setState(() => _priority = 3)),
                  ],
                ),
                const SizedBox(height: 12),
                SizedBox(width: double.infinity, child: ElevatedButton.icon(onPressed: _selectedSubjectId == null ? null : () => _addTask(uid), icon: const Icon(Icons.add), label: const Text('Add Task'))),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildTaskCard(String id, Map<String, dynamic> data, String uid) {
    final isDone = data['isCompleted'] ?? false;
    final priority = data['priority'] ?? 1;
    final dueDate = DateTime.parse(data['dueDate'] ?? DateTime.now().toIso8601String());
    final isOverdue = dueDate.isBefore(DateTime.now()) && !isDone;
    Color priorityColor = Colors.green;
    if (priority == 2) priorityColor = Colors.orange;
    if (priority == 3) priorityColor = Colors.red;

    return Slidable(
      endActionPane: ActionPane(motion: const ScrollMotion(), children: [
        SlidableAction(onPressed: (_) => _deleteTask(id, uid), backgroundColor: Colors.red, foregroundColor: Colors.white, icon: Icons.delete, label: 'Delete'),
      ]),
      child: Card(
        margin: const EdgeInsets.only(bottom: 10),
        color: isDone ? Colors.grey.shade100 : null,
        child: ListTile(
          leading: Checkbox(value: isDone, onChanged: (v) => _toggleTask(id, v ?? false, uid)),
          title: Text(data['title'] ?? 'Task', style: TextStyle(decoration: isDone ? TextDecoration.lineThrough : null, fontWeight: isDone ? FontWeight.normal : FontWeight.bold)),
          subtitle: Row(
            children: [
              Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2), decoration: BoxDecoration(color: priorityColor.withOpacity(0.2), borderRadius: BorderRadius.circular(8)), child: Text(priority == 1 ? 'Normal' : priority == 2 ? 'Important' : 'Urgent', style: TextStyle(fontSize: 11, color: priorityColor))),
              const SizedBox(width: 8),
              Text(DateFormat('yyyy-MM-dd').format(dueDate), style: TextStyle(fontSize: 12, color: isOverdue ? Colors.red : Colors.grey)),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _addTask(String uid) async {
    if (_titleCtrl.text.trim().isEmpty) return;
    await FirebaseFirestore.instance.collection('users').doc(uid).collection('tasks').add({
      'title': _titleCtrl.text.trim(), 'subjectId': _selectedSubjectId, 'dueDate': _dueDate.toIso8601String(),
      'isCompleted': false, 'priority': _priority, 'createdAt': Timestamp.now(),
    });
    _titleCtrl.clear(); setState(() { _priority = 1; _selectedSubjectId = null; });
  }

  Future<void> _toggleTask(String id, bool value, String uid) async {
    await FirebaseFirestore.instance.collection('users').doc(uid).collection('tasks').doc(id).update({'isCompleted': value});
  }

  Future<void> _deleteTask(String id, String uid) async {
    await FirebaseFirestore.instance.collection('users').doc(uid).collection('tasks').doc(id).delete();
  }

  @override void dispose() { _titleCtrl.dispose(); super.dispose(); }
}
