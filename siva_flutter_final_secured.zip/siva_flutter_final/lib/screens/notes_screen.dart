import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_slidable/flutter_slidable.dart';

class NotesScreen extends StatefulWidget {
  const NotesScreen({super.key});
  @override State<NotesScreen> createState() => _NotesScreenState();
}

class _NotesScreenState extends State<NotesScreen> {
  final _titleCtrl = TextEditingController();
  final _contentCtrl = TextEditingController();
  String? _editingId;

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return const Center(child: Text('Please login'));

    return Scaffold(
      appBar: AppBar(title: const Text('Notes')),
      body: Column(
        children: [
          Card(
            margin: const EdgeInsets.all(16),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  TextField(controller: _titleCtrl, decoration: InputDecoration(labelText: 'Note Title', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)))),
                  const SizedBox(height: 12),
                  TextField(controller: _contentCtrl, decoration: InputDecoration(labelText: 'Content', border: OutlineInputBorder(borderRadius: BorderRadius.circular(12))), maxLines: 4),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(child: ElevatedButton.icon(onPressed: () => _saveNote(user.uid), icon: Icon(_editingId == null ? Icons.add : Icons.save), label: Text(_editingId == null ? 'Add Note' : 'Save Changes'))),
                      if (_editingId != null) ...[const SizedBox(width: 8), TextButton.icon(onPressed: _cancelEdit, icon: const Icon(Icons.cancel), label: const Text('Cancel'))],
                    ],
                  ),
                ],
              ),
            ),
          ),
          const Divider(),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance.collection('users').doc(user.uid).collection('notes').orderBy('updatedAt', descending: true).snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
                final docs = snapshot.data!.docs;
                if (docs.isEmpty) return const Center(child: Text('No notes yet'));
                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: docs.length,
                  itemBuilder: (context, index) {
                    final doc = docs[index];
                    final data = doc.data() as Map<String, dynamic>;
                    return _buildNoteCard(doc.id, data, user.uid);
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNoteCard(String id, Map<String, dynamic> data, String uid) {
    return Slidable(
      endActionPane: ActionPane(motion: const ScrollMotion(), children: [
        SlidableAction(onPressed: (_) => _startEdit(id, data), backgroundColor: Colors.blue, foregroundColor: Colors.white, icon: Icons.edit, label: 'Edit'),
        SlidableAction(onPressed: (_) => _deleteNote(id, uid), backgroundColor: Colors.red, foregroundColor: Colors.white, icon: Icons.delete, label: 'Delete'),
      ]),
      child: Card(
        margin: const EdgeInsets.only(bottom: 12),
        child: ListTile(
          title: Text(data['title'] ?? 'Note', style: const TextStyle(fontWeight: FontWeight.bold)),
          subtitle: Text(data['content'] ?? '', maxLines: 2, overflow: TextOverflow.ellipsis),
        ),
      ),
    );
  }

  Future<void> _saveNote(String uid) async {
    if (_titleCtrl.text.trim().isEmpty) return;
    final data = {'title': _titleCtrl.text.trim(), 'content': _contentCtrl.text.trim(), 'updatedAt': Timestamp.now()};
    if (_editingId == null) { data['createdAt'] = Timestamp.now(); await FirebaseFirestore.instance.collection('users').doc(uid).collection('notes').add(data); }
    else { await FirebaseFirestore.instance.collection('users').doc(uid).collection('notes').doc(_editingId).update(data); }
    _cancelEdit();
  }

  void _startEdit(String id, Map<String, dynamic> data) {
    setState(() { _editingId = id; _titleCtrl.text = data['title'] ?? ''; _contentCtrl.text = data['content'] ?? ''; });
  }

  void _cancelEdit() { setState(() { _editingId = null; _titleCtrl.clear(); _contentCtrl.clear(); }); }

  Future<void> _deleteNote(String id, String uid) async {
    await FirebaseFirestore.instance.collection('users').doc(uid).collection('notes').doc(id).delete();
  }

  @override void dispose() { _titleCtrl.dispose(); _contentCtrl.dispose(); super.dispose(); }
}
