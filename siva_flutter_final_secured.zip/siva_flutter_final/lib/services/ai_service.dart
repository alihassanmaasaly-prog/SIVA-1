import 'package:google_generative_ai/google_generative_ai.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

class AIService {
  // Gemini API Key - loaded from .env (never commit real keys to source control)
  static String get _apiKey => dotenv.env['GEMINI_API_KEY'] ?? '';

  final model = GenerativeModel(
    model: 'gemini-pro',
    apiKey: _apiKey,
  );

  /// Study assistant - answers student questions
  Future<String> askStudyQuestion(String question, String subject) async {
    final prompt = 'You are an expert Arabic study assistant specializing in ' + subject + '. Answer this question in simple Arabic for students: ' + question;
    final response = await model.generateContent([Content.text(prompt)]);
    return response.text ?? 'Sorry, I did not understand the question. Try rephrasing it.';
  }

  /// Summarize lessons - shortens any study text
  Future<String> summarizeText(String text) async {
    final prompt = 'Summarize this study text into main points in Arabic: ' + text;
    final response = await model.generateContent([Content.text(prompt)]);
    return response.text ?? 'Could not summarize. Make sure the text is clear.';
  }

  /// Generate quiz questions
  Future<String> generateQuiz(String topic, int count) async {
    final prompt = 'Create ' + count.toString() + ' multiple choice questions in Arabic about: ' + topic + '. Each question has 4 options (A B C D). Mark correct answer.';
    final response = await model.generateContent([Content.text(prompt)]);
    return response.text ?? 'Could not create questions. Try a different topic.';
  }

  /// Smart study plan
  Future<String> createStudyPlan(String subjects, int days) async {
    final prompt = 'Create a detailed Arabic study plan for ' + days.toString() + ' days for subjects: ' + subjects + '. Include daily schedule with Pomodoro breaks.';
    final response = await model.generateContent([Content.text(prompt)]);
    return response.text ?? 'Could not create plan.';
  }

  /// Explain difficult topic
  Future<String> explainTopic(String topic, String level) async {
    final prompt = 'Explain this topic in simple Arabic for ' + level + ' level: ' + topic + '. Use daily life examples. Divide into: Definition, Main Idea, Examples, Application.';
    final response = await model.generateContent([Content.text(prompt)]);
    return response.text ?? 'Could not explain. Try a different topic.';
  }

  /// Check homework
  Future<String> checkHomework(String question, String studentAnswer) async {
    final prompt = 'You are an Arabic teacher. Review this homework. Question: ' + question + '. Student Answer: ' + studentAnswer + '. Evaluate in Arabic. Be encouraging.';
    final response = await model.generateContent([Content.text(prompt)]);
    return response.text ?? 'Could not evaluate. Make sure the text is correct.';
  }
}
