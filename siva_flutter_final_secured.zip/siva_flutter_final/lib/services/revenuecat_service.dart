import 'dart:io';
import 'package:purchases_flutter/purchases_flutter.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

class RevenueCatService extends ChangeNotifier {
  bool _isPro = false;
  bool _isLoading = true;
  Offerings? _offerings;

  bool get isPro => _isPro;
  bool get isLoading => _isLoading;
  Offerings? get offerings => _offerings;

  // RevenueCat API Key - loaded from .env (never commit real keys to source control)
  static String get _apiKey => dotenv.env['REVENUECAT_API_KEY'] ?? '';

  Future<void> init() async {
    await Purchases.setLogLevel(LogLevel.debug);
    await Purchases.configure(
      PurchasesConfiguration(_apiKey)
        ..appUserID = null,
    );
    await _checkProStatus();
    await _fetchOfferings();
    _isLoading = false;
    notifyListeners();
  }

  Future<void> _checkProStatus() async {
    try {
      final customerInfo = await Purchases.getCustomerInfo();
      _isPro = customerInfo.entitlements.all['pro']?.isActive ?? false;
      notifyListeners();
    } catch (e) {
      debugPrint('Error checking pro status: $e');
    }
  }

  Future<void> _fetchOfferings() async {
    try {
      _offerings = await Purchases.getOfferings();
      notifyListeners();
    } catch (e) {
      debugPrint('Error fetching offerings: $e');
    }
  }

  Future<bool> purchasePackage(Package package) async {
    try {
      final customerInfo = await Purchases.purchasePackage(package);
      _isPro = customerInfo.entitlements.all['pro']?.isActive ?? false;
      notifyListeners();
      return _isPro;
    } catch (e) {
      debugPrint('Purchase error: $e');
      return false;
    }
  }

  Future<void> restorePurchases() async {
    try {
      final customerInfo = await Purchases.restorePurchases();
      _isPro = customerInfo.entitlements.all['pro']?.isActive ?? false;
      notifyListeners();
    } catch (e) {
      debugPrint('Restore error: $e');
    }
  }
}
