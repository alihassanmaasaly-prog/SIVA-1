import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ChatService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  String get _uid => _auth.currentUser?.uid ?? '';

  Future<void> sendMessage(String text) async {
    if (text.trim().isEmpty || _uid.isEmpty) return;
    await _db.collection('chat_global').add({
      'uid': _uid,
      'text': text.trim(),
      'timestamp': FieldValue.serverTimestamp(),
      'email': _auth.currentUser?.email ?? 'User',
    });
  }

  Stream<QuerySnapshot> getMessages() {
    return _db.collection('chat_global')
      .orderBy('timestamp', descending: true)
      .limit(100)
      .snapshots();
  }

  Future<void> deleteMessage(String messageId) async {
    await _db.collection('chat_global').doc(messageId).delete();
  }
}
